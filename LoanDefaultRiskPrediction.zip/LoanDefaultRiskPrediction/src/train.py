from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier


def train_logistic_regression(X, y, C=1, max_iter=1000, penalty='l2', solver='liblinear'):
    """
    Train Logistic Regression.
    """
    lr_model = LogisticRegression(
        C=C,
        max_iter=max_iter,
        penalty=penalty,
        solver=solver,
        random_state=42,
        class_weight='balanced'
    )
    lr_model.fit(X, y)
    return lr_model


def train_random_forest(X, y, n_estimators=300, max_depth=10,
                        min_samples_split=10, min_samples_leaf=5):
    """
    Train Random Forest classifier.
    """
    rf_model = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_split=min_samples_split,
        min_samples_leaf=min_samples_leaf,
        random_state=42,
        class_weight='balanced',
        n_jobs=-1
    )
    rf_model.fit(X, y)
    return rf_model


def train_gradient_boosting(X, y, n_estimators=300,
                            learning_rate=0.05,
                            max_depth=4,
                            subsample=0.8):
    """
    Train Gradient Boosting classifier.
    """
    gb_model = GradientBoostingClassifier(
        n_estimators=n_estimators,
        learning_rate=learning_rate,
        max_depth=max_depth,
        subsample=subsample,
        random_state=42
    )
    gb_model.fit(X, y)
    return gb_model
