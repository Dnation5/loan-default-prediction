# src/config.py

# Raw Dataset path
DATA_PATH = "../data/raw/loan_default.csv"

# Path to processed dataset
DATA_PATH_2 = "../data/processed/loan_default_processed.csv"

# File path for the updated loan default dataset containing engineered features
DATA_PATH_3 = "../data/updated/loan_default_updated.csv"
