from sklearn.metrics import (recall_score, confusion_matrix, accuracy_score, roc_auc_score, 
                             f1_score, precision_score)

def evaluate_model(model, X_test, y_test):
    """
    Evaluate model performance on test set.
    """
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    accuracy = accuracy_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    roc_auc = roc_auc_score(y_test, y_prob)
    conf_matrix = confusion_matrix(y_test, y_pred)


    return {
        "Accuracy": accuracy,
        "Recall": recall,
        "Precision": precision,
        "F1 Score": f1,
        "Confusion_Matrix": conf_matrix,
        "ROC_AUC": roc_auc
    }

def compare_models(models, X_test, y_test):
    """
    Compare multiple trained models.
    """
    results = {}

    for name, model in models.items():
        results[name] = evaluate_model(model, X_test, y_test)

    return results
