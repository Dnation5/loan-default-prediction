import pandas as pd 
import numpy as np 


def create_income_to_loan_ratio(data):
    data["Income_Loan_Ratio"] = data["Income"] / data["LoanAmount"]
    return data

def create_employment_stability(data):
    data["Stable_Employment"] = data["MonthsEmployed"] > 24
    return data

def create_high_dti(data):
    data['High_DTI'] = data['DTIRatio'] > 0.4
    return data



def feature_engineering_pipeline(data): 
    data = data.copy()

    """
Feature engineering pipeline.

Creates the following features:
Income-to-Loan Ratio: 'Income_Loan_Ratio'
Employment Stability Flag: 'Stable_Employment'
High DTI Flag: 'High_DTI'


data: pandas DataFrame containing original features
:return: pandas DataFrame with new engineered features
"""


    data = create_income_to_loan_ratio(data)
    data = create_employment_stability(data)
    data = create_high_dti(data)
    

    return data 

